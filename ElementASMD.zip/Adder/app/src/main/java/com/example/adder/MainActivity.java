package com.example.adder;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static android.text.TextUtils.*;

public class MainActivity extends AppCompatActivity {
    EditText fno;
    EditText sno;
    Button add;
    Button sub;
    Button mul;
    Button div,clr;
    TextView ans;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fno=(EditText) findViewById(R.id.fno);
        sno=(EditText) findViewById(R.id.sno);
        add=(Button) findViewById(R.id.add);
        sub=(Button) findViewById(R.id.sub);
        mul=(Button) findViewById(R.id.mul);
        div=(Button) findViewById(R.id.div);
        clr=(Button) findViewById(R.id.clr);
        ans=(TextView) findViewById(R.id.ans);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(fno.getText().toString()) || TextUtils.isEmpty(sno.getText().toString()) )
                {
                    Toast.makeText(MainActivity.this, "plz enter nos ", Toast.LENGTH_SHORT).show();
                    return;
                }
                double n1=Double.parseDouble(fno.getText().toString());
                double n2=Double.parseDouble(sno.getText().toString());
                double sum=n1+n2;
                ans.setText("Addition is "+Double.toString(sum));
            }
        });
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(fno.getText().toString()) || TextUtils.isEmpty(sno.getText().toString()) )
                {
                    Toast.makeText(MainActivity.this, "plz enter nos ", Toast.LENGTH_SHORT).show();
                    return;
                }
                double n1=Double.parseDouble(fno.getText().toString());
                double n2=Double.parseDouble(sno.getText().toString());
                double sub=n1-n2;
                ans.setText("Subtraction is "+Double.toString(sub));
            }
        });
        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(fno.getText().toString()) || TextUtils.isEmpty(sno.getText().toString()) )
                {
                    Toast.makeText(MainActivity.this, "plz enter nos ", Toast.LENGTH_SHORT).show();
                    return;
                }
                double n1=Double.parseDouble(fno.getText().toString());
                double n2=Double.parseDouble(sno.getText().toString());
                double mul=n1*n2;
                ans.setText("Multiplication is "+Double.toString(mul));
            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(fno.getText().toString()) || TextUtils.isEmpty(sno.getText().toString()) )
                {
                    Toast.makeText(MainActivity.this, "plz enter nos ", Toast.LENGTH_SHORT).show();
                    return;
                }
                double n1=Double.parseDouble(fno.getText().toString());
                double n2=Double.parseDouble(sno.getText().toString());
                double div=n1/n2;
                ans.setText("Division is "+Double.toString(div));
            }
        });
        clr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fno.setText("");
                sno.setText("");
                ans.setText("");
            }
        });

    }
}
